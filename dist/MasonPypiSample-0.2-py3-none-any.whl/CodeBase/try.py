

def mason_output():
    print("mason test 0218")