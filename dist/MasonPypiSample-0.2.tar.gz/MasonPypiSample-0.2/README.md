# Mason Pypi learning

This is a example program for mason learning。
## github link

need to add
## update new .gz

```
python setup.py sdist
```
## update new wheel

```
python setup.py sdist bdist_wheel 
```

## upload to pypi

```
python -m twine upload dist/* --verbose
```
## reference
[參考](https://medium.com/%E8%B3%87%E5%B7%A5%E7%AD%86%E8%A8%98/%E6%89%93%E5%8C%85python-module-%E5%88%B0pypi-%E4%B8%8A-aef1f73e1774)"# PypiSampleCode" 
"# PypiSampleCode" 
